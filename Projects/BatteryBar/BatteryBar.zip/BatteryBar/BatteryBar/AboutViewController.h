//
//  AboutViewController.h
//  
//
//  Created by Matthew Stallone on 6/20/15.
//
//

#import <Cocoa/Cocoa.h>

@interface AboutViewController : NSViewController

@end
