//
//  NotificationKeys.h
//  BatteryBar
//
//  Created by Matthew Stallone on 6/19/15.
//  Copyright © 2015 Matthew Stallone. All rights reserved.
//

#define kSegmentValueChanged @"SegmentValueChangedNotification"
#define kOpacityChanged @"OpacityChangedNotification"
#define kThicknessChanged @"ThicknessChangedNotification"