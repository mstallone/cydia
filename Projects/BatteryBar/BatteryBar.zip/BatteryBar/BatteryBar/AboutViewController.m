//
//  AboutViewController.m
//  
//
//  Created by Matthew Stallone on 6/20/15.
//
//

#import "AboutViewController.h"
#import "NotificationKeys.h"

@interface AboutViewController ()

@end

@implementation AboutViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do view setup here.
}

- (IBAction)segmentValueChanged:(id)sender {
    [[NSNotificationCenter defaultCenter] postNotificationName:kSegmentValueChanged object:[NSNumber numberWithLong:[sender selectedSegment]]];
}
@end
