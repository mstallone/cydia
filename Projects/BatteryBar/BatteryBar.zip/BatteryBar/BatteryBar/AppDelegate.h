//
//  AppDelegate.h
//  BatteryBar
//
//  Created by Matthew Stallone on 6/19/15.
//  Copyright © 2015 Matthew Stallone. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>
@property (retain) NSWindowController *batterBarWindowController, *preferencesWindowController;

@end

