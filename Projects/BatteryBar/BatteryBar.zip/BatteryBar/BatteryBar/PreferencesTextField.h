//
//  PreferencesTextField.h
//  
//
//  Created by Matthew Stallone on 6/21/15.
//
//

#import <Cocoa/Cocoa.h>

@interface PreferencesTextField : NSTextField

@end
