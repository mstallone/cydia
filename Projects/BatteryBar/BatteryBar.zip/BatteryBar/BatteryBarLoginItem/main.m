//
//  main.m
//  BatteryBarLoginItem
//
//  Created by Matthew Stallone on 6/20/15.
//  Copyright (c) 2015 Matthew Stallone. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
