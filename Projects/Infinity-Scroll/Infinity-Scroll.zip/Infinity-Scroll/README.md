# Infinity-Scroll
Infinity page scroll (implemented for NSDate) using UIPageViewController

## Demo
![alt tag](http://i.imgur.com/QauOOCu.gif)
