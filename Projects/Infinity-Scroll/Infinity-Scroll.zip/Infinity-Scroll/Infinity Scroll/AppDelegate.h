//
//  AppDelegate.h
//  Infinity Scroll
//
//  Created by Matthew Stallone on 11/25/15.
//  Copyright © 2015 Matthew Stallone. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

