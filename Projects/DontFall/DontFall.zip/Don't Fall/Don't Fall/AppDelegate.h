//
//  AppDelegate.h
//  Don't Fall
//
//  Created by Matthew Stallone on 12/22/14.
//  Copyright (c) 2014 Matthew Stallone. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

