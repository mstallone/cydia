//
//  GameScene.h
//  Don't Fall
//

//  Copyright (c) 2014 Matthew Stallone. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>
#import <CoreMotion/CoreMotion.h>

typedef enum _State {
    Start, Playing, Pause
} State;

@interface GameScene : SKScene<SKPhysicsContactDelegate> {
    CMMotionManager *motionManager;
    NSMutableArray *platforms;
    NSTimeInterval lastTime, secondCounter, contactTimeCounter;
    State currentState;
    SKSpriteNode *effect, *player;
    SKLabelNode *scoreLabel;
    long scoreCount;
}

@end
