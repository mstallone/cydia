word = list(input())
if(len(word) > 0): word[0] = word[0].upper()
print(''.join(word))