//
//  AppDelegate.h
//  Tube
//
//  Created by Matthew Stallone on 9/27/15.
//  Copyright © 2015 Matthew Stallone. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

