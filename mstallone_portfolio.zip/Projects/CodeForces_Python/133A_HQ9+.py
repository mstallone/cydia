code = input()
print("YES") if "H" in code or "Q" in code or "9" in code else print("NO")